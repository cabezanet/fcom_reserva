@extends('layout')

@section('title')
    <title>Solicitud de registro sistema de reserva de espacios Fcom.</title>
@stop



@section('content')

   
  <div class="panel panel-success col-md-6 col-md-offset-3 well well-md" style="padding:0px;margin-top:40px;height:300px">
    <div class="panel-heading">
      <h4><i class="fa fa-check-square-o fa-fw"></i> Solicitud de acceso sistema de reserva de espacios Fcom.</h4>
    </div>
      
    <div class="panel-body" >
    
      
        
        <p class="text-success text-center" style="margin:75px 20px">
          Su petición se ha realizado con éxito.
          <br />
          En 24/48 horas podrá acceder al sistema con su <abbr title="Usuario Virtual de la Universidad de Sevilla">UVUS</abbr>.
        </p>

   

   </div><!-- /.panel-body -->
      
   </div> <!-- /.panel-default -->

@stop